let regForm = document.querySelector(".register-form");
let allInput = regForm.querySelectorAll("INPUT");
let allBtn = regForm.querySelectorAll("BUTTON")
let closeBtn = document.querySelector(".btn-close");
let regList = document.querySelector(".reg-list");
let addBtn = document.querySelector(".add-btn");
var dataCounter = document.getElementById("datacounter");
let allRegData = [];
let selData = [];




if (localStorage.getItem("allRegData") != null) {
    allRegData = JSON.parse(localStorage.getItem("allRegData"));
}
console.log(allRegData);

regForm.onsubmit = (e) => {
    e.preventDefault();
    let checkEmail = allRegData.find((data) => data.email == allInput[2].value);
    if (checkEmail == undefined) {
        allRegData.push({
            name: allInput[0].value,
            mobile: allInput[1].value,
            email: allInput[2].value,
            dob: allInput[3].value,
            class: allInput[4].value,
        });
        localStorage.setItem("allRegData", JSON.stringify(allRegData));
        Swal.fire({
            title: "Data Inserted",
            text: "Successfully",
            icon: "success"
        });
        // console.log("cls", closeBtn);
        closeBtn.click();
        regForm.reset(' ');
        getRegData();
    }
    else {
        Swal.fire({
            title: "ERROR",
            text: "Email Already Exist",
            icon: "error"
        });
    }

}

const getRegData = () => {
    regList.innerHTML = "";
    allRegData.forEach((data, index) => {
        let dataStr = JSON.stringify(data);
        let finalData = dataStr.replace(/"/g, "'");
        regList.innerHTML += `
        <tr>
        <td>${index + 1}</td>
        <td>${data.name}</td>
        <td>${data.mobile}</td>
        <td>${data.email}</td>
        <td>${data.dob}</td>
        <td>${data.class}</td>
        <td>
            <button data="${finalData}" index="${index}" class="edit-btn btn p-1 px-2 btn-primary">
                <i class="fa fa-edit"></i>
            </button>
            <button index="${index}" class="del-btn btn p-1 px-2 btn-danger">
                <i class="fa fa-trash"></i>
            </button>
            <button data="${finalData}"  index="${index}" class="sel-btn btn p-1 px-2 btn-info">
                <i class="fa fa-eye"></i>
            </button>
        </td>
    </tr>
        `;
    })
    action();
}

const action = () => {
    // delete operation
    let allDelBtn = regList.querySelectorAll(".del-btn");
    for (let btn of allDelBtn) {
        btn.onclick = () => {
            let index = btn.getAttribute("index");
            allRegData.splice(index, 1);
            localStorage.setItem("allRegData", JSON.stringify(allRegData));
            getRegData();
            Swal.fire({
                title: "Data Deleted",
                text: "Successfully",
                icon: "success"
            });

        }
    }


    // select opertion
    let selectBtn = regList.querySelectorAll(".sel-btn");
    for (let btn of selectBtn) {
        btn.onclick = () => {
             let index = btn.getAttribute("index");
             let dataStr = btn.getAttribute("data");
             if (localStorage.getItem("allRegData") == null) {
                        allRegData = [];
                    } else {
                       let selealctedData = localStorage.setItem("allSelData", JSON.stringify(dataStr));
                    }
                  var countupdate =()=>{
                    dataCounter.innerHTML=selData.length+1
                  }  
                  countupdate();
        }
    }
        //  update operation
        let allEditBtn = regList.querySelectorAll(".edit-btn");
        for (let btn of allEditBtn) {
            btn.onclick = () => {
                let index = btn.getAttribute("index");
                let dataStr = btn.getAttribute("data");
                let finalData = dataStr.replace(/'/g, '"')
                let data = JSON.parse(finalData);
                addBtn.click();
                allInput[0].value = data.name;
                allInput[1].value = data.mobile;
                allInput[2].value = data.email;
                allInput[3].value = data.dob;
                allInput[4].value = data.class;
                allBtn[0].disabled = false;
                allBtn[1].disabled = true;

                allBtn[0].onclick = () => {
                    allRegData[index] = {
                        name: allInput[0].value,
                        mobile: allInput[1].value,
                        email: allInput[2].value,
                        dob: allInput[3].value,
                        class: allInput[4].value
                    }
                    localStorage.setItem("allRegData", JSON.stringify(allRegData));
                    Swal.fire({
                        title: "Data Updated",
                        text: "Successfully",
                        icon: "success"
                    });
                    // console.log("cls", closeBtn);
                    closeBtn.click();
                    regForm.reset(' ');
                    getRegData();
                    selectedData();
                    allBtn[1].disabled = false;
                    allBtn[0].disabled = true;
                }
            }

        }
}


getRegData();